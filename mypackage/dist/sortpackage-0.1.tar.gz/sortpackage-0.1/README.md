#Basic Python Functions
Quicksort, Mergesort, Bubblesort
